﻿using System;

namespace Exercise_1
{
    class Program
    {
        public  int i ;
        
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.WriteLine("Please enter number");
            Console.ReadLine();
            for (i = 1; i < 4; i++)
            {
                Console.WriteLine("1");
                Console.WriteLine("121");
                Console.WriteLine("12321");
                Console.WriteLine("1234321");
            }
            

            


                    
            


        }
    }
}
